for x in range (-1, 13):
        print(x , str("am"))
for y in range(11,24):
    print(y , str("pm"))
        
