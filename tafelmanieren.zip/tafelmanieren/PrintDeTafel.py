while True:
    tafel = int(input("welke getal tafel wil je?:"))
    for x in range(1,13):
        print(tafel, "x" , x , "=", tafel * x)

